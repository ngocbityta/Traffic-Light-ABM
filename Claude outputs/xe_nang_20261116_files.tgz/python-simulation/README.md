# Python simulation

Mô phỏng độc lập ngã tư Lê Văn Lương – Hoàng Đạo Thúy nằm trong
`simulation/python_simulation/`. Logic Python dùng GeoJSON trong
`simulation/python_simulation/includes/`; model GAML được quản lý riêng ở
`gama-simulation/`.

## Chạy mô phỏng

```bash
python3 python-simulation/simulation/python_simulation/python_sim.py \
  --seed 1 --cycles 4000 --output train/results/lvl_python.csv
```

## Giao diện quan sát

```bash
python3 scripts/lvl_observer_server.py --port 8765 --seed 1
```

Mở `http://127.0.0.1:8765/`. Trang hỗ trợ chạy, tạm dừng, bước mô phỏng,
đặt lại seed và xem thông tin xe. Giao diện nằm trong `ui/`; script dựng bố cục
và GeoJSON nằm trong `scripts/`.

Các kiểm thử Python được đặt trong `tests/`.

## Cấu hình dùng chung cho UI và train

Mô phỏng Python mặc định dùng `junction_model="negotiation"`. Có thể dùng cùng
một file JSON cho giao diện và huấn luyện:

```json
{
  "junction_model": "negotiation",
  "yellow": 4.0,
  "all_red": 2.0,
  "vehicle_params": {"motorbike": {"headway": 0.75}},
  "heavy_ratio": 0.03,
  "startup_params": {"reaction_delay": 0.7}
}
```

Truyền `--sim-config config.json` cho `scripts/lvl_observer_server.py` và
`python -m train.logic.train`. Cũng có thể truyền trực tiếp JSON kết quả của
`calibrate_discharge.py` (trường `kwargs`). Training lưu cấu hình đã áp dụng
trong `training_config.json` và `training_summary.json`; evaluate đọc lại từ
summary, hoặc nhận `--sim-config` để ghi đè. Evaluate ghi cấu hình thực dùng
ra file `<output>.sim_config.json`; file này có thể nạp lại bằng `--sim-config`.

Trong chế độ `safe`, xe rẽ phải được đi khi đèn đỏ nhưng phải được cấp quyền
vào nút và nhường xe đi thẳng tại vùng nhập làn. Bộ đếm
`permitted_right_on_red_entries` tách các lượt rẽ phải hợp lệ khỏi
`entries_during_red`.

## Hàng chờ và chọn làn

Xe đi thẳng có thể xuất hiện ở bất kỳ sublane hợp lệ nào trên đường vào,
bao gồm vùng làn rẽ phải. Khi tiến gần nút, xe phải nhập vào vùng làn đi
thẳng trước khi tới hàng đầu chờ đèn; nếu chưa có khe hở an toàn, xe giữ
khoảng cách ở vùng đệm phía trước vạch dừng. Demand ghép cặp và model GAMA
giữ nguyên làn xuất hiện đã yêu cầu.
Ở chế độ Python `safe`, mỗi xe có một khoảng lùi dừng cố định theo seed
(xe máy 0–1,8 m; ô tô 0–1,2 m). Xe máy tiến vào hàng chờ đỏ có thể lọc sang
sublane kế bên khi có đủ khoảng trống trước, sau và bên hông, đồng thời còn
đủ đường để hoàn tất đổi làn trước vạch dừng. Chế độ `gama_2025_6_4` giữ
quy tắc dừng của GAMA để phục vụ đối chiếu.

Quy tắc lọc làn dựa trên quan sát về xe máy trong hàng chờ tại Hà Nội và
TP.HCM trong [nghiên cứu của Minh và cộng sự](https://onlinelibrary.wiley.com/doi/10.1002/atr.144)
và [nghiên cứu về lọc làn ở nút giao có đèn](https://onlinelibrary.wiley.com/doi/10.1155/2022/5662117).
Cách chia sublane và giữ khoảng hở bên hông tham khảo
[tài liệu SUMO](https://eclipse.dev/sumo/docs/Simulation/SublaneModel.html).
Các khoảng lùi và ngưỡng lọc hiện là giả định mô phỏng, chưa được hiệu chỉnh
bằng quỹ đạo xe đo tại ngã tư này.

## Đèn vàng, quyết định dừng/đi (13/11/2026)

`LeVanLuongSimulator(yellow=4.0)` (mặc định 4 s) lấy 4 s cuối mỗi pha xanh làm
đèn vàng; độ dài chu kỳ và thời điểm bắt đầu xanh không đổi. Có thể truyền
`yellow=0` cho các benchmark cần kế hoạch cũ. Ở chế độ train, mỗi lần đổi pha
có 4 s vàng rồi tới 2 s đỏ toàn phần.

Khi vàng bật, mỗi xe chưa qua vạch quyết định dừng/đi một lần theo logit Point
Data Model của Chauhan, Dhamaniya & Arkatkar (2022, TRF 89:222–235):
U = 4,518 + 0,106·v[m/s] − 0,083·x[m] − 1,068·ô tô − 0,923·làn giữa −
1,049·làn sát dải phân cách. Xe không thể dừng với gia tốc ≤ 6 m/s² luôn đi.
Quyết định "đi" còn hiệu lực trong đỏ toàn phần và hết hiệu lực khi pha kế
tiếp xanh. Số liệu Ấn Độ; việc áp dụng cho Hà Nội là giả định.
Xe ở quá xa để tới nút trước pha xanh đối hướng phải chọn dừng.

## Tham số hành vi và hiệu chỉnh

`vehicle_params={"motorbike": {"headway": 0.8}, "car": {"gap": 1.5}}` và
`startup_params={"reaction_delay": 1.0, "discharge_headway": 0.9}` thay giá trị
mặc định (`DEFAULT_VEHICLE_PARAMS`). `scripts/calibrate_discharge.py` đo lưu
lượng bão hòa và thời gian tổn thất khởi động, và tìm tham số khớp với số đo
thực địa bạn cung cấp (`--targets targets.json`).

## Chấp nhận khe và lách ngang trong nút (16/11/2026)

- **Chấp nhận khe theo logit** (`negotiation_params={"gap_model": "logit"}`,
  mặc định; `"sumo"` trả lại luật impatience kiểu SUMO). Xe rẽ trái gặp xe đi
  thẳng đang xanh quyết định một lần cho mỗi khe theo Vu & Shimizu (2010):
  xe máy V = 2,449·TG − 0,045·EWT + 0,198·MC1 − 2,257, ô tô V = 2,887·TG +
  0,127·EWT + 0,165·V1 − 4,225; TG = khe dọc − khe ngang (s), EWT thời gian
  chờ, MC1 số xe máy trong nhóm (xe cách nhau ≤ 4 m là một nhóm). Số ngẫu nhiên
  cố định theo (seed, xe, khe). Xe theo sau trong nhóm đi theo xe dẫn đầu.
  `neg.gap_events` ghi quyết định đầu tiên của mỗi khe để so với bài báo.
- **Lách ngang của xe đi thẳng** (`"evade": true`). Xe đi thẳng trong nút
  đang phải phanh vì một xe rẽ trái có thể dịch 1–3 sublane để **cắt đuôi**
  (đi sau đuôi xe rẽ trái) hoặc **lách lên trước** (đi trước, buộc xe rẽ trái
  chưa cam kết phanh nhẹ, ≤ 0,5·a_max). Chọn dải lệch ít nhất vẫn đi tiếp
  được (Trinh và cs. 2018). Hướng lái giới hạn ±30° với xe máy (Trinh 2018),
  ±0,2 rad với ô tô (Kanagaraj & Treiber 2018). Mỗi dải mới được kiểm tra chỗ
  trống trên connector và thời gian với mọi xe xung đột. Xác suất sẵn lòng
  (`evade_cut_*`, `evade_front_*`) đã hiệu chỉnh để tỷ lệ thực hiện khớp
  Vu & Shimizu. Kết quả đo (seed 1–3, 3000 tick): xe máy dẫn đầu cắt đuôi
  17 % và lách lên trước 5 % (bài báo: 20 % và 5 %), ô tô 3 % và 3 % (bài báo:
  5 % và 2 %; chỉ có 89 sự kiện ô tô). `adapter.evade_events` ghi từng lần lách.
- Kiểm tra va chạm ngang khi đổi làn giờ tính cả xe vừa qua mối nối
  connector → đường ra.

Kiểm thử: `tests/test_logit_evade_20261116.py`.

## Xe nặng (16/11/2026)

Mô phỏng có ba loại xe: xe máy, ô tô và **xe nặng** (gộp xe tải, xe buýt, xe
khách). Mã loại trong file demand (cột thứ ba): 0 xe máy, 1 ô tô, 2 xe nặng.
File demand cũ chỉ có 0/1 vẫn đọc được.

| Tham số | Xe nặng | Ô tô | Nguồn |
|---|---|---|---|
| Dài × rộng (m) | 9,0 × 2,45 | 4,5 × 1,7 | SUMO: truck 7,1 × 2,4, bus 12 × 2,5; trộn 59:41 theo số đếm `small_truck_bus` : `heavy_truck_bus` của nút Nguyễn Trãi – Khuất Duy Tiến |
| Số sublane chiếm | 3 | 2 | ⌈rộng / 1,05 m⌉, tương đương `num_lanes_occupied` của GAMA |
| a (m/s²) | 1,25 | 2,5 | SUMO `getDefaultAccel`: truck 1,3, bus 1,2 |
| b (m/s²) | 2,7 | 3,0 | SUMO `getDefaultDecel`: xe nặng 4,0 so với ô tô 4,5; cùng tỷ lệ áp lên b của ô tô |
| s0 (m) | 1,0 | 1,0 | SUMO dùng cùng `minGap` cho ô tô, truck, bus |
| T (s) | 1,5 | 1,2 | `time_headway` mặc định của driving skill GAMA |
| Tốc độ mong muốn | N(50; 2,5) km/h | N(50; 5) km/h | SUMO `speedFactor`: trung bình 1, độ lệch truck 0,05 so với ô tô 0,1 |
| Tỷ lệ trong dòng xe | 3 % | 12 % | 85 % xe máy giữ nguyên; 15 % còn lại chia theo tỷ lệ ô tô : xe nặng của số đếm trên |

Các tham số nằm ở `DEFAULT_VEHICLE_PARAMS` và `DEFAULT_HEAVY_RATIO` trong
`python_sim.py`. Ghi đè bằng `vehicle_params={"heavy": {...}}` và
`heavy_ratio`, qua `--sim-config` (khóa `heavy_ratio`), `--heavy-ratio` của
`python_sim.py`, `lvl_observer_server.py` và `ssm_report.py`.
`heavy_ratio=0` cho kết quả trùng từng bit với mô hình hai loại xe trước đây.

Hành vi riêng:
- **Đèn vàng:** logit Chauhan và cs. (2022) dùng hệ số "Bus & LCV" −1,471 của
  cùng bảng (bài báo ghi hệ số này không có ý nghĩa thống kê ở mức 5 %).
- **Trong nút:** xe nặng dùng luật chấp nhận khe và nhường của ô tô. Xe nặng
  không lách ngang (`evade_cut_heavy = evade_front_heavy = 0`), vì số liệu
  Vu & Shimizu chỉ có xe máy và ô tô dẫn đầu. Khi đếm chỗ chờ trong nút, một
  xe nặng tính bằng 4 xe máy.
- **Đổi làn:** thời gian dịch ngang dài hơn ô tô (hệ số 1,3, giả định).
- **Thân xe khớp nối:** xe dài hơn ô tô được chia thành các đoạn dài bằng ô tô
  (xe 9 m thành 2 đoạn 4,5 m). Mỗi đoạn tiếp tuyến với đường đi tại tâm của
  nó. Một hình chữ nhật cứng 9 m tiếp tuyến tại tâm sẽ chìa mũi hoặc đuôi ra
  ~0,8 m ở các đoạn gấp khúc ~10° tại mối vạch dừng, đè lên xe đứng cạnh.
  SUMO và GAMA đều vẽ xe uốn theo làn. Bộ chống chồng thân trên connector và
  giao diện dùng thân khớp nối này.
- **Độ chìa thân (`body_sweep`):** phần góc của mỗi đoạn vẫn ra ngoài dải
  sublane khi đường cong dưới nó. Độ chìa này cộng vào bề rộng trong các luật
  giữ khoảng cách ngang với xe phía trước và phía sau. Nó không áp cho xe đang
  chạy song song, cũng không áp trong bộ đẩy lùi trên đường, để tránh biến một
  xe bên cạnh thành "xe trước" với khoảng cách âm. Ô tô và xe máy không có độ
  chìa, giữ nguyên hành vi cũ.
- **Mối vạch dừng:** xe trên nhánh vào bám theo một xe nặng vừa qua mối nối
  giữ thêm khoảng cách bằng độ chìa của xe nặng. `_resolve_seam_overlaps`
  chặn xe sau trước khi chạm đuôi xe nặng, chỉ trong quãng vừa đi của tick.
- **Hai xe cùng chờ nhập làn đứng song song** (`_release_mutual_merge`): hành
  lang đi thẳng chỉ có hai vị trí chồng nhau cho xe 3 sublane, nên hai xe nặng
  đứng cạnh nhau ở vùng đệm nhập làn chặn nhau mãi (nhánh SE không xả được ở
  10 % xe nặng). Sau 8 s, xe nhích trước hơn được đi tiếp qua vùng đệm, vượt
  hẳn thân xe kia rồi nhập làn; xe kia nhập sau.
- **Quãng nhích dự đoán của xe trước** (`_leader_advance`): xe trước chưa được
  phép qua vạch và sắp tới điểm dừng có thể phanh tới `max_decel` (khi đèn đổi
  pha). Xe sau không còn tính một bước nhích đầy đủ của nó, nên không bị đẩy
  lùi vài cm nữa.

Kết quả đo, kế hoạch cố định, 4 seed × 3000 tick (600 s). Mốc là cùng seed với
0 % xe nặng (trùng từng bit với mô hình trước đây):

| Chỉ số mỗi seed | 0 % xe nặng | 3 % xe nặng |
|---|---|---|
| Xe qua | 1454–1549 | 1455–1528 |
| Thời gian trong mạng trung bình (s): xe máy / ô tô / xe nặng | 43–44 / 42–45 / — | 45–48 / 46–49 / 52–58 |
| Cặp chồng thân có xe nặng | — | 0, 0, 1, 0 (sâu 0,07 m, 1 tick) |
| Cặp chồng thân mọi loại xe | 1–2 | 1–6 |
| Trong đó sâu > 0,1 m | 0–1 | 0–5 |
| Xe bị gỡ do kẹt / lần đẩy lùi | 0 / 0 | 0 / 0 |
| Lần phanh > 9 m/s² | 15–24 | 25–54 |

Chế độ train và thử tải, 8000 tick (1600 s), seed 1–2:

| | 0 % (ngẫu nhiên) | 3 % (ngẫu nhiên / đổi pha liên tục) | 10 % (cố định) |
|---|---|---|---|
| Xe qua | 4133–4145 | 4128–4141 | 3985–4044 |
| Xe còn trong mạng cuối lượt | 112–132 | 111–125 | 201–274 |
| Xe bị gỡ do kẹt | 0 | 0 | 0 |
| Lần đẩy lùi (lớn nhất) | 0 | 0–1 (0,06 m) | 41–136 (0,22 m) |
| Lần phanh > 9 m/s² | 44–53 | 73–120 | 421–492 |

Nhận xét:
- Cùng số xe đến, thay ô tô bằng xe nặng làm nút xả chậm hơn: lưu lượng một
  pha xanh giảm khoảng 10 % ở 3 % xe nặng (đo bằng `measure_discharge`). Ở
  nhu cầu 2400 xe/h mỗi nhánh nút gần bão hòa, nên 10 % xe nặng gây ùn nhẹ.
- Các cặp chồng thân tăng thêm chủ yếu là **ô tô và xe máy** ở mối vạch dừng
  của nhánh SE (connector gấp khúc ~10°). Đây là điểm yếu sẵn có của mô hình
  thân cứng cho mọi loại xe; hàng chờ dày hơn khi có xe nặng làm nó xảy ra
  thường hơn. Chưa sửa vì sửa sẽ đổi hành vi của ô tô và xe máy. Hướng xử lý:
  áp `_resolve_seam_overlaps` cho mọi cặp xe, hoặc làm trơn đoạn gấp khúc
  trong `build_layout.py`.
- Phanh gắt tăng chủ yếu ở xe máy và xe nặng quanh mối nối, cùng cơ chế chốt
  chặn vị trí đã có với ô tô.
- 10 % xe nặng là phép thử tải: không kẹt, nhưng đẩy lùi và phanh gắt tăng
  rõ. Nếu số đếm thực của nút cho tỷ lệ cao như vậy, cần rà lại các chốt chặn
  vị trí với xe dài trước khi train.

Tạo demand cho model GAMA: `generate_demand(..., heavy_ratio=0)`. Các script
đối chiếu với GAMA đã đặt sẵn như vậy, vì model GAML chưa có xe nặng. Train
với backend GAMA cũng sinh demand không có xe nặng. Đánh giá một lượt train
cũ (cấu hình chưa có `heavy_ratio`) dùng 0 % xe nặng như lúc train.

Kiểm thử: `tests/test_heavy_vehicles_20261116.py`.

## Chỉ số an toàn thay thế (SSM)

`scripts/ssm_report.py --seed 1 --ticks 3000 --save run.npz` ghi quỹ đạo
(`python_simulation/trajectory.py`) và tính offline
(`python_simulation/ssm.py`): TTC, MTTC (có gia tốc), time gap, DRAC,
TET/TIT, PET tại các điểm xung đột cấp sublane, TTC 2D trong nút và phanh gấp.

## Điều kiện để train (15/11/2026)

Các thay đổi sau áp dụng cho chế độ `safe`; chế độ `gama_2025_6_4` giữ nguyên
để đối chiếu với GAMA.

- **Xanh tối thiểu.** `min_green=10.0` (s). `sim.action_mask()` chỉ cho đổi pha
  khi pha đang chạy đã xanh đủ lâu; `set_action` với action bị che được coi là
  giữ pha (đếm trong `masked_actions`). Với quyết định mỗi 10 s và 6 s
  vàng + đỏ toàn phần, agent đổi pha nhanh nhất mỗi 20 s.
- **Giữ trống lòng nút.** `negotiation_params={"box_clear": true}` (mặc định):
  xe của pha mới chỉ chờ ở vạch dừng khi nó thật sự phải nhường một xe sót
  của pha cũ, tức xe sót chưa kịp rời vùng xung đột trước lúc xe này tới nơi.
  Xe sót sắp ra khỏi vùng xung đột không giữ ai lại. Khi một xe đã vào nút và
  đang chờ xe sót, chỉ dải ngang của xe đó bị đóng, các sublane khác vẫn mở.
  Đặt `false` để trả lại hành vi lách qua xe sót.
- **Xe trước qua mối vạch dừng.** Một xe chỉ là "xe trước" khi thân nó nằm
  cùng dải ngang (tính theo bề rộng thân xe, kể cả dải nó đang dịch sang). Xe
  ở sublane bên cạnh, hoặc xe đi song song trên connector tách hướng, không
  giữ xe ở vạch.
- **Lưới an toàn chống kẹt.** `jam_timeout=120.0` (s): xe đứng yên trên
  connector lâu hơn ngưỡng bị gỡ khỏi mô phỏng và đếm trong `jam_removed`
  (tương tự time-to-teleport của SUMO). Một lần chạy lành mạnh có
  `jam_removed == 0`; khác 0 nghĩa là có kẹt cần điều tra.
- **Giới hạn động học.** `curve_lat_accel=3.0` m/s² giới hạn tốc độ trên cung
  rẽ (v ≤ √(a·R) theo đường đi thực của sublane), có giảm tốc trước cua với
  `curve_decel=2.0` m/s²; đặt 0 để tắt. `max_decel=7.5` m/s² là giới hạn phanh
  của luật bám xe; các lần bảo vệ vị trí đòi phanh gấp hơn được đếm trong
  `hard_brake_events`. Tốc độ là tốc độ thực trên đường đi của xe: tiến độ
  trên đường tham chiếu được quy đổi theo độ dài cung của sublane.
- **Sinh xe.** Xe vào mô hình với tốc độ mong muốn, giảm theo khoảng cách tới
  xe phía trước cùng dải ngang.
- **Tất định.** Cùng seed cho cùng kết quả ở mọi tiến trình, không phụ thuộc
  `PYTHONHASHSEED`.

Các tham số trên nhận qua `--sim-config` (xem `sim_config.py`). Bộ kiểm thử
`tests/test_train_readiness_20261115.py` và `tests/test_green_yield_20261116.py`
giữ các điều kiện này.
